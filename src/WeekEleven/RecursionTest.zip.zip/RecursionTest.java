package WeekEleven;

public class RecursionTest {
    public static void main(String[] args) {
        Recursion recursion = new Recursion();

        System.out.println("Counting Down:");
        recursion.countDown(10); // Calling countDown() with an integer argument

        System.out.println("\nAlphabet Backwards:");
        recursion.alphaBackwards('z'); // Calling alphaBackwards() with a character argument


    }
}
