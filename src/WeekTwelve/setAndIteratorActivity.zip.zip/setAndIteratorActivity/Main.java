package WeekTwelve.setAndIteratorActivity;

public class Main {
    public static void main(String[] args) {
        // Create an instance of the GymScheduledSet class
        GymScheduledSet gymSet = new GymScheduledSet();

        // Call the addScheduledClass() method
        gymSet.addScheduledClass();

        // Call the displayScheduledClasses() method
        gymSet.displayScheduledClasses();
    }
}
